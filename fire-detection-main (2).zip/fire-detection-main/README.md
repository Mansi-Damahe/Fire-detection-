# fire-detection
🔥 Real-time fire detection using YOLOv8 🚒📸 for accurate image-based fire recognition with Python.
